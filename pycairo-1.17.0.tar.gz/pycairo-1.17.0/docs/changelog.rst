Changelog
=========

.. currentmodule:: cairo

.. include:: ../NEWS
